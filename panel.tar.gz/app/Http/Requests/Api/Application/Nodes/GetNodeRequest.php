<?php

namespace Pterodactyl\Http\Requests\Api\Application\Nodes;

class GetNodeRequest extends GetNodesRequest
{
}
